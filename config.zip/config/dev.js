const test = {
  app: {
    port: 8020,
    morgan: {
      type: "tiny",
      options: ""
    }
  },
  database: "mongodb://165.227.76.110:27017/test",
  jwt: {
    secret: "secret",
  } 
}

module.exports = test;
