const test = {
  app: {
    port: 8030,
    morgan: {
      type: "tiny",
      options: ""
    }
  },
  database: "mongodb+srv://test:t3st@cluster0-rvf31.gcp.mongodb.net/test?retryWrites=true",
  jwt: {
    secret: "secret",
  } 
}

module.exports = test;
